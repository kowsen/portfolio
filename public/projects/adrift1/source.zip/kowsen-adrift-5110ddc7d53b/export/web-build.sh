#!/bin/bash

mkdir -p dist/web
rm -r dist/web
mkdir -p dist/web
cp data/web/manifest.json dist/web
cp data/web/service_worker.js dist/web
cp data/web/icon.png dist/web
cp data/web/icon-apple.png dist/web
cp data/web/icon-small.png dist/web
cp data/web/feedback.html dist/web
cp data/web/index.html dist/web
cp data/web/install.html dist/web
cp data/web/play.html dist/web
cp data/web/loading.gif dist/web
cp data/web/nosleep.min.js dist/web
echo "$(uuidgen)" > dist/web/version.txt

cp build/web/* dist/web
cp build/android/Adrift.apk dist/web
rm dist/web/Adrift.html
