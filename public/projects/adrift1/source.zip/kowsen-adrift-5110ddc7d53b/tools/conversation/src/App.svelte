<script>
  import './setup-responsive';
  import './styles/global.scss';

  import { Router, Route } from 'svelte-routing';
  import Content from './Content.svelte';
  import { name } from './store';
  import { loadConversation, saveConversation } from './printer';

  export let url = '';

  let upload;

  function onUpload(event) {
    loadConversation(event.target.files[0]);
  }
</script>

<div class="content">
  <Router {url}>
    <div class="header">
      <h1>Conversation Generator</h1>
      <input type="text" bind:value={$name}>
      <button on:click={saveConversation}>SAVE</button>
      <button on:click={() => upload.click()}>LOAD</button>
      <input type="file" style="display:none;" accept=".gd" bind:this={upload} on:change={onUpload}>
    </div>

    <main>
      <Route path="/" component={Content} />

      <Route>
        <p>PAGE NOT FOUND</p>
      </Route>
    </main>
  </Router>
</div>

<style>
  .content {
    padding: 24px;
  }

  .header {
    display: flex;
    align-items: center;
  }
  
  .header h1 {
    margin-right: auto;
  }

  .header button {
    max-height: 24px;
  }

  .header input {
    max-width: 150px;
  }
</style>
