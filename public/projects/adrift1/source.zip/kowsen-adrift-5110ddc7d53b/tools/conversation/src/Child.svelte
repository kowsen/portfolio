<script>
    import { createEventDispatcher } from 'svelte';

    const dispatch = createEventDispatcher();

    export let node = {};

    function onClick() {
        dispatch('click');
    }
</script>

<button on:click={onClick}>
    <p>Verb: <span>{node.verb}</span></p>
    <p>flags: <span>{node.requiredRunFlags} + {node.requiredGameFlags}</span></p>
    <p>minTime: <span>{node.minTime}</span></p>
    <p>maxTime: <span>{node.maxTime}</span></p>
</button>

<style>
    button {
        text-align: left;
        min-width: 150px;
    }

    span {
        font-weight: bolder;
        color: rgb(185, 8, 8);
    }
</style>