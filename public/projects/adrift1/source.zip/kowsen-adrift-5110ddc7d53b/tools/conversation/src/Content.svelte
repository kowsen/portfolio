<script>
  import { addVoice, currentNode, traversalStr, nodeIds, deleteVoice, modifyCurrentNode, moveDown, moveUp, setVoice, showUpArrow, STUB_MESSAGE, voices, STUB_NODE, traversal } from './store';
  import { saveConversation } from './printer';
  import { safeSubscribe } from './util/safe-patch';
  import { get } from 'svelte/store';
  import Child from './Child.svelte';
  import Message from './Message.svelte';
  import Voice from './Voice.svelte';

  export let location;

  let messagesSelect;
  let childrenSelect;

  let showVoices = false;
  $: voiceMessage = showVoices ? 'Hide Voices' : 'Show Voices';

  function _warn() {
    console.log(location);
  }

  let shadowNode = get(currentNode);

  safeSubscribe(currentNode, node => {
    shadowNode = clone(node);
    if (messagesSelect) {
      messagesSelect.value = shadowNode.messagesShadow || '';
    }
    if (childrenSelect) {
      childrenSelect.value = shadowNode.childrenShadow || '';
    }
  });

  function save() {
    saveConversation();
  }

  function update() {
    modifyCurrentNode(node => {
      node.id = shadowNode.id;
      node.verb = shadowNode.verb;
      node.requiredRunFlags = shadowNode.requiredRunFlags;
      node.requiredGameFlags = shadowNode.requiredGameFlags;
      node.triggerRunFlags = shadowNode.triggerRunFlags;
      node.triggerGameFlags = shadowNode.triggerGameFlags;
      node.minTime = shadowNode.minTime;
      node.maxTime = shadowNode.maxTime;
      node.messages = clone(shadowNode.messages);
      node.messagesShadow = shadowNode.messagesShadow;
      node.children = clone(shadowNode.children);
      node.childrenShadow = shadowNode.childrenShadow;
    });
  }

  function clickChild(index) {
    moveDown(index);
  }

  function clickUpArrow() {
    moveUp();
  }

  function moveChild(index, dIndex) {
    modifyCurrentNode(node => {
      const toMove = node.children[index];
      node.children.splice(index, 1);
      node.children.splice(index + dIndex, 0, toMove);
    });
  }

  function deleteChild(index) {
    modifyCurrentNode(node => {
      node.children.splice(index, 1);
    });
  }

  function updateMessage(newMessage, index) {
    modifyCurrentNode(node => {
      node.messages[index] = newMessage;
    });
  }

  function updateVoice(voice, index) {
    setVoice(index, voice);
  }

  function addMessage() {
    modifyCurrentNode(node => {
      node.messages.push(STUB_MESSAGE);
    });
  }

  function deleteMessage(index) {
    modifyCurrentNode(node => {
      node.messages.splice(index, 1);
    });
  }

  function addChild() {
    modifyCurrentNode(node => {
      node.children.push(STUB_NODE);
    });
  }

  function clone(val) {
    return JSON.parse(JSON.stringify(val));
  }
</script>

<button on:click={() => showVoices = !showVoices}>{voiceMessage}</button>

{#if showVoices}
  <div class="voice-container">
    {#each $voices as voice, i}
      <Voice voice={voice} on:update={(event) => updateVoice(event.detail, i)}></Voice>
      <button class="delete-voice" on:click={() => deleteVoice(i)}>X</button>
    {/each}
    <button class="add" on:click={addVoice}>+</button>
  </div>
{/if}

<div class="condition-container">
  {#if $showUpArrow}
    <button on:click={clickUpArrow}>UP</button>
    <span>{$traversalStr}</span>

    
    <div>
      <span>ID:</span>
      <input type="text" bind:value={shadowNode.id} on:input={update}>
    </div>

    {#if $traversal.length > 1}
      <div>
        <span>Verb:</span>
        <input type="text" bind:value={shadowNode.verb} on:input={update}>
      </div>
    {/if}

    <div>
      <span>Req run flags:</span>
      <input type="text" bind:value={shadowNode.requiredRunFlags} on:input={update}>
    </div>

    <div>
      <span>Req game flags:</span>
      <input type="text" bind:value={shadowNode.requiredGameFlags} on:input={update}>
    </div>
  {/if}

  <div>
    <span>Trigger run flags:</span>
    <input type="text" bind:value={shadowNode.triggerRunFlags} on:input={update}>
  </div>

  <div>
    <span>Trigger game flags:</span>
    <input type="text" bind:value={shadowNode.triggerGameFlags} on:input={update}>
  </div>

  {#if $showUpArrow}
    <div>
      <span>min_time:</span>
      <input type="number" bind:value={shadowNode.minTime} on:input={update}>
    </div>

    <div>
      <span>max_time:</span>
      <input type="number" bind:value={shadowNode.maxTime} on:input={update}>
    </div>
  {/if}
</div>

{#if $showUpArrow}
  <p>MESSAGES</p>
  {#each shadowNode.messages as message, i}
    <div class="message-box">
      <Message message={message} on:update={(event) => updateMessage(event.detail, i)}></Message>
      <button on:click={() => deleteMessage(i)}>X</button>
    </div>
  {:else}
    <span>Message Shadow: </span>
    <!-- svelte-ignore a11y-no-onchange -->
    <select bind:this={messagesSelect} bind:value={shadowNode.messagesShadow} on:change={update}>
        <option selected="selected" value="">
            NONE
        </option>
        {#each $nodeIds as nodeId}
            <option value={nodeId}>
                {nodeId}
            </option>
        {/each}
    </select>
  {/each}
  <button on:click={addMessage}>+</button>
{/if}

<p>CHILDREN</p>
<div class="children-container">
  {#each shadowNode.children as child, i}
    <div class="child-container">
      <Child node={child} on:click="{() => clickChild(i)}"></Child>
      <div class="child-controls">
        {#if i > 0}
          <button on:click={() => moveChild(i, -1)}>&lt;</button>
        {:else}
          <button>-</button>
        {/if}
        {#if i < shadowNode.children.length - 1}
          <button on:click={() => moveChild(i, 1)}>&gt;</button>
        {:else}
          <button>-</button>
        {/if}
        <button on:click={() => deleteChild(i)}>X</button>
      </div>
    </div>
  {:else}
    <span>Child Shadow: </span>
    <!-- svelte-ignore a11y-no-onchange -->
    <select bind:this={childrenSelect} bind:value={shadowNode.childrenShadow} on:change={update}>
        <option selected="selected" value="">
            NONE
        </option>
        {#each $nodeIds as nodeId}
            <option value={nodeId}>
                {nodeId}
            </option>
        {/each}
    </select>
  {/each}
</div>
<button on:click={addChild}>+</button>

<style>
  .voice-container {
    display: flex;
    flex-wrap: wrap;
  }

  .condition-container {
    background-color: #FAE5E5;
    padding: 12px;
    margin-top: 12px;
  }

  .condition-container button {
    margin-bottom: 12px;
  }

  .condition-container span {
    width: 140px;
  }

  .condition-container div {
    display: flex;
    align-items: center;
  }

  .message-box {
    display: flex;
    width: 100%;
    margin: 8px 0;
  }

  .child-container {
    display: flex;
    margin: 8px;
  }

  .child-controls {
    display: flex;
    flex-direction: column;
  }

  .child-controls * {
    flex-grow: 1;
  }

  .children-container {
    display: flex;
    flex-wrap: wrap;
  }
</style>