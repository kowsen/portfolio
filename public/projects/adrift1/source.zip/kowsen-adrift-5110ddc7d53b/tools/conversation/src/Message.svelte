<script>
    import { createEventDispatcher } from 'svelte';
import { voices } from './store';
import { safeSubscribe } from './util/safe-patch';

    const dispatch = createEventDispatcher();

    let lastMessage;
    export let message;

    let messageClone;

    let select;

    $: {
        if (lastMessage !== message) {
            messageClone = JSON.parse(JSON.stringify(message));
            lastMessage = message;
            if (!message.voice && select) {
                select.selectedIndex = 0;
            }
        }
    }

    function update() {
        dispatch('update', messageClone);
    }

    safeSubscribe(voices, ($voices) => {
        setTimeout(() => {
            if (!$voices.find(({id}) => id === messageClone.voice) && select) {
                select.selectedIndex = 0;
            }
        }, 0);
    });
</script>

<div class="container">
    <div>
        <span>Voice: </span>
        <!-- svelte-ignore a11y-no-onchange -->
        <select bind:this={select} bind:value={messageClone.voice} on:change={update}>
            <option selected="selected">
                INVALID
            </option>
            {#each $voices as voice}
                <option value={voice.id}>
                    {voice.id}
                </option>
            {/each}
        </select>
    </div>
    <div>
        <span>Speed: </span>
        <input type="number" bind:value={messageClone.speed} on:input={update}>
    </div>
    <div>
        <span>Wait: </span>
        <input type="number" bind:value={messageClone.wait} on:input={update}>
    </div>
    <div>
        <span>Text: </span>
        <textarea bind:value={messageClone.text} on:input={update}></textarea>
    </div>
</div>

<style>
    .container {
        background-color: #ccc;
        padding: 12px;
        flex-grow: 1;
    }

    .container div {
        display: flex;
        align-items: center;
    }

    .container div span {
        width: 46px;
    }

    .container div input, .container div select, .container div textarea {
        flex-grow: 1;
    }

    textarea {
        min-height: 100px;
    }
</style>
