<script>
    import { createEventDispatcher } from 'svelte';

    const dispatch = createEventDispatcher();

    let lastVoice;
    export let voice;

    let voiceClone;
    let color;

    $: {
        if (lastVoice !== voice) {
            voiceClone = JSON.parse(JSON.stringify(voice));
            lastVoice = voice;
            color = `#${voice.color.toString(16).padStart(6, '0')}`;
        }
    }

    function update() {
        dispatch('update', {...voiceClone, color: parseInt(color.slice(1), 16)});
    }
</script>

<div class="container">
    <div>
        <span>id: </span>
        <input type="text" bind:value={voiceClone.id} on:input={update}>
    </div>
    <div>
        <span>font: </span>
        <input type="text" bind:value={voiceClone.font} on:input={update}>
    </div>
    <div>
        <span>size: </span>
        <input type="number" bind:value={voiceClone.size} on:input={update}>
    </div>
    <div>
        <span>color: </span>
        <input type="color" bind:value={color} on:input={update}>
    </div>
    <div>
        <span>style: </span>
        <input type="text" bind:value={voiceClone.style} on:input={update}>
    </div>
    <div>
        <span>preLine: </span>
        <input type="text" bind:value={voiceClone.preLine} on:input={update}>
    </div>
</div>

<style>
    .container {
        background-color: #ccc;
        padding: 12px;
    }

    .container div {
        display: flex;
        align-items: center;
    }

    .container div span {
        width: 46px;
    }

    .container div input {
        flex-grow: 1;
    }
</style>