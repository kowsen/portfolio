import { saveAs } from 'file-saver';
import { get } from 'svelte/store';

import { populatedRoot, voices, name, root, STUB_NODE } from './store';

function buildMessage(message) {
	const r = Math.floor(message.color / 0x10000) % 0x100;
	const g = Math.floor(message.color / 0x100) % 0x100;
	const b = message.color % 0x100;
	const color = `Color8(${r}, ${g}, ${b})`;
	return `MessageData.new(Font.${message.font}, ${message.size}, ${color}, FontStyle.${message.style}, "${message.preLine}", ${message.wait}, ${message.speed}, "${message.text.replaceAll('\n', '\\n')}")`;
}

function buildConversationNode(node, childrenIndexMap) {
	const messages = node.messages.map(message => buildMessage(message));
	const children = node.children.map(child => childrenIndexMap.get(child));
	const requiredRunFlags = flagsToString(node.requiredRunFlags);
	const requiredGameFlags = flagsToString(node.requiredGameFlags);
	const triggerRunFlags = flagsToString(node.triggerRunFlags);
	const triggerGameFlags = flagsToString(node.triggerGameFlags);
	const flags = `FlagInfo.new(${requiredRunFlags}, ${requiredGameFlags}, ${triggerRunFlags}, ${triggerGameFlags})`;
	return `ConversationNode.new("${node.verb}", ${node.minTime}, ${node.maxTime}, ${flags}, [${messages}], [${children}])`;
}

function flagsToString(flags) {
	return `[${flags.split(',').filter(x => !!x).map(x => `"${x}"`)}]`;
}

function buildConversation(root) {
	let nextIndex = 0;
	const childrenIndexMap = new Map();
	traverseTree(root, (next) => {
		childrenIndexMap.set(next, nextIndex);
		nextIndex += 1;
	});
	const nodes = [];
	traverseTree(root, (next) => {
		nodes.push(buildConversationNode(next, childrenIndexMap));
	});
	return `ConversationData.new([${nodes}])`;
}

function traverseTree(root, cb) {
	const queue = [root];
	while (queue.length > 0) {
		const next = queue.shift();
		for (const child of next.children) {
			queue.push(child);
		}
		cb(next);
	}
}

function buildOutput(populatedRoot, root, voices, name) {
	return `# ${JSON.stringify(root)}
# ${JSON.stringify(voices)}
# ${name}
# END_OF_HEADER

extends Resource

var FontStyle = Fonts.FontStyle
var Font = Fonts.Font

var conversation = ${buildConversation(populatedRoot)}
`;
}

async function readFile(file) {
	return new Promise(resolve => {
		const reader = new FileReader();
		reader.addEventListener('load', (event) => {
		  resolve(event.target.result);
		});
		reader.readAsText(file);
	});
  }

export async function loadConversation(file) {
	const txt = await readFile(file);
	const header = txt.split('# END_OF_HEADER')[0];
	const chunks = header.split('\n# ');
	chunks[0] = chunks[0].slice(2)
	const lastIndex = chunks.length - 1;
	chunks[lastIndex] = chunks[lastIndex].slice(0, -1);

	const $root = JSON.parse(chunks[0]);
	const $voices = JSON.parse(chunks[1]);
	const $name = chunks[2];

	root.set($root);
	voices.set($voices);
	name.set($name);
}

export function saveConversation() {
    const text = buildOutput(get(populatedRoot), get(root), get(voices), get(name));
    const blob = new Blob([text], {type: "text/plain;charset=utf-8"});
    saveAs(blob, `${get(name)}.gd`);
}
