import { writable, derived, get } from 'svelte/store';

export const STUB_VOICE = {
    id: 'untitled',
    font: 'DEFAULT',
    size: 32,
    color: 0xffffff,
    style: 'DEFAULT',
    preLine: '',
};

export const STUB_NODE = {
    id: '',
    verb: '',
    requiredRunFlags: "",
    requiredGameFlags: "",
    triggerRunFlags: "",
    triggerGameFlags: "",
    minTime: -1,
    maxTime: -1,
    messagesShadow: undefined,
    messages: [],
    childrenShadow: undefined,
    children: [],
};

export const STUB_MESSAGE = {
    voice: '',
    text: '',
    wait: 0,
    speed: 0.04,
};

export const name = writable('Untitled');

export const voices = writable([]);

export const voiceMap = derived(voices, $voices => {
    const map = {};
    for (const voice of $voices) {
        const id = voice.id;
        const stripVoice = {...voice};
        delete stripVoice.id;
        map[id] = stripVoice;
    }
    return map;
});

// voice: id: {font, size, color, style}

export function setVoice(index, voice) {
    voices.update($voices => {
        const newVoices = [...$voices];
        newVoices[index] = voice;
        return newVoices;
    });
}

export function deleteVoice(index) {
    voices.update($voices => {
        const newVoices = [...$voices];
        newVoices.splice(index, 1);
        return newVoices;
    });
}

export function addVoice() {
    voices.update($voices => {
        const newVoices = [...$voices];
        newVoices.push(STUB_VOICE);
        return newVoices;
    });
}

// message: {voice, speed, text}
// node: {verb, minTime, maxTime, messages, children}
export const root = writable(STUB_NODE);

// array of indexes into children array
export const traversal = writable([]);

export const traversalStr = derived(traversal, $traversal => {
    const $root = get(root);
    const nodes = [];
    let node = $root;
    for (const index of $traversal) {
        node = node.children[index];
        nodes.push(node);
    }
    return nodes.map(node => {
        let description = [];
        if (node.verb) {
            description.push(node.verb);
        }
        if (node.requiredRunFlags || node.requiredGameFlags) {
            description.push(`(${node.requiredRunFlags || '___'}, ${node.requiredGameFlags || '___'})`);
        }
        if (node.minTime !== -1 || node.maxTime !== -1) {
            description.push(`<${node.minTime}, ${node.maxTime}>`);
        }
        return description.length > 0 ? description.join(' ') : 'ANY';
    }).join(' --> ');
});

export const showUpArrow = derived(traversal, $traversal => $traversal.length > 0);

export const nodeIds = derived(root, $root => getNodeIds($root));

export function moveUp() {
    traversal.update($traversal => $traversal.slice(0, -1));
}

export function moveDown(index) {
    traversal.update($traversal => $traversal.concat(index));
}

export const currentNode = derived([root, traversal], ([$root, $traversal]) => {
    return navigateTree($root, $traversal);
});

export function modifyCurrentNode(cb) {
    const copy = clone(get(root));
    const node = navigateTree(copy, get(traversal));
    cb(node);
    root.set(copy);
}

export const populatedRoot = derived([voiceMap, root], ([$voiceMap, $root]) => {
    const clonedRoot = clone($root);
    traverseTree(clonedRoot, (node) => {
        node.messages = node.messages.map(message => {
            const voice = $voiceMap[message.voice];
            const newMessage = {...message, ...voice};
            delete newMessage['voice'];
            return newMessage;
        });
    });
    traverseTree(clonedRoot, node => {
        node.messages = getMessagesForNode(clonedRoot, node);
        node.children = getChildrenForNode(clonedRoot, node);
    });
    return clonedRoot;
});

function clone(val) {
    return JSON.parse(JSON.stringify(val));
}

function traverseTree(root, cb) {
	const queue = [root];
	while (queue.length > 0) {
		const next = queue.shift();
		for (const child of next.children) {
			queue.push(child);
		}
		cb(next);
	}
}

function getNodeIds(root) {
    const ids = [];
    traverseTree(root, node => {
        if (node.id) {
            ids.push(node.id);
        }
    });
    return ids;
}

function getNodeById(root, id) {
    let node = null;
    traverseTree(root, possible => {
        if (possible.id === id) {
            node = possible;
        }
    });
    return node;
}

function getMessagesForNode(root, node) {
    while (node.messagesShadow) {
        node = getNodeById(root, node.messagesShadow);
    }
    return node.messages;
}

function getChildrenForNode(root, node) {
    while (node.childrenShadow) {
        node = getNodeById(root, node.childrenShadow);
    }
    return node.children;
}

function navigateTree($root, $traversal) {
    let node = $root;
    for (const index of $traversal) {
        node = node.children[index];
    }
    return node;
}

